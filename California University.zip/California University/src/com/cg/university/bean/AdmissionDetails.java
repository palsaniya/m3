package com.cg.university.bean;

public class AdmissionDetails 
{

	private String firstName;
	private String lastName;
	private String mobileNo;
	private String email;
	private String stream;
	private String aggMarks;

	
	public AdmissionDetails() {

	}
	
	//initializing instance variables
	public AdmissionDetails(String firstName,String lastName, String mobileNo, String email,String stream, String aggMarks)
	{
		this.firstName = firstName;
		this.lastName = lastName;
		this.email = email;
		this.mobileNo = mobileNo;
		this.aggMarks = aggMarks;
		this.stream = stream;
	}
	
	
	public String getaggMarks() {
		return aggMarks;
	}
	
	public void setaggMarks(String aggMarks) {
		this.aggMarks = aggMarks;
	}
	
	public String getfirstName() {
		return firstName;
	}
	
	public void setfirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getlastName() {
		return lastName;
	}
	
	public void setlastName(String lastName) {
		this.lastName = lastName;
	}
	
	public String getstream() {
		return stream;
	}
	
	public void setstream(String stream) {
		this.stream = stream;
	}
	public String getemail() {
		return email;
	}

	public void setemail(String email) {
		this.email = email;
	}
	
	public void getmobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}
	
		public String setmobileNo() {
			return mobileNo;
	}
	
	@Override
	public String toString() {
		return "Asset [First Name=" + firstName+ ", Last Name="
				+ lastName + ", Mobile =" + mobileNo +", Email =" + email + " Stream =" + stream +" Aggregate =" + aggMarks + "]" ;
	}
}
