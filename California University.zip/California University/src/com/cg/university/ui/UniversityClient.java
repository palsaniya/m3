package com.cg.university.ui;


import java.util.Scanner;


import com.cg.university.bean.AdmissionDetails;
import com.cg.university.exception.AdmissionException;
import com.cg.university.helper.CollectionHelper;
import com.cg.university.helper.DataValidator;

public class UniversityClient 
{
	static Scanner sc=new Scanner(System.in);
	static Scanner sc1=new Scanner(System.in);
	static CollectionHelper collectionhelper=null;
	static String mobile;
	
	//Main method
	public static void main(String[] args)
	{
		String choice;
		collectionhelper=new CollectionHelper();

		while(true)
		{
			//Providing user interface
			System.out.println("University Management \n***************** \n1. Enter admission details\n"
					+ "2. Display admission details\n"+ "3. Delete admission details based on mobile number\n"
					+ "4. Find the number of admissions done\n" + "5. Exit");
			
			System.out.println("\nEnter your choice :");
			choice=sc.next();
			switch(choice)
			{
			
			//Calling enterUniversityDetails method for getting & displaying University details 
			case "1":enterUniversityDetails();break;
			case "2":collectionhelper.displayAllAdmissions();break;
			case "3":System.out.println("Enter the number"); mobile=sc.next(); 
			if((boolean) collectionhelper.deleteAdmissions(mobile))
				{
				 System.out.println("Details are deleted");
				}
			else
			{
				System.out.println("No such details found");
			
			};break;
			case "4":collectionhelper.numberAdmissions();break;
			case "5":System.out.println("Exiting...");System.exit(0);
			default: System.out.println("Please enter correct choice");
			break;
			}
		}
	}
	
	//method for getting & displaying University details
	private static void enterUniversityDetails() 
	{
		System.out.println("Enter First Name:");
		String firstName=sc1.nextLine();
		try 
		{
			
			if(DataValidator.validatefirstName(firstName))
			{
				System.out.println("Enter Last Name:");
				String lastName=sc.next();
				//sending input to validateUniversityType method for validating University name
				if(DataValidator.validatelastName(lastName))
				{
					System.out.println("Enter Contact Number:");
					String mobileNo=sc.next();
										
					//sending input to validateUniversityQuanity method for validating University UniversityNumber
					if(DataValidator.validatemobileNo(mobileNo))
					{
						System.out.println("Enter Email Id:");
						String email=sc.next();
														
						if(DataValidator.validateemail(email))
						{
							System.out.println("Enter Stream :");
							String stream=sc1.nextLine();
						
						
						if(DataValidator.validatestream(stream))
						{
							System.out.println("Enter Aggregate in qualifying exam :");
							String aggMarks=sc.next();

							if(DataValidator.validateaggMarks(aggMarks))
							{
						
							AdmissionDetails cc=new AdmissionDetails(firstName, lastName,mobileNo, email,stream,aggMarks);
						
						collectionhelper.addNewAdmission(cc);
						
						collectionhelper.displayAllAdmissions();
						}
					}
					}	
				}
			}
			
		} 
	}
		catch (AdmissionException e)
		{			
			System.out.println(e.getMessage());
		}		

	}
}
