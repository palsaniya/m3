package com.cg.university.helper;

import java.util.regex.Pattern;

import com.cg.university.exception.AdmissionException;




public class DataValidator 
{
	public  static  boolean validatefirstName(String firtName)throws AdmissionException
	{
		String assetPattern="[A-Za-z]{3,15}";
		if(Pattern.matches(assetPattern, firtName))
		{
			return true;
		}
		else
		{
			throw new AdmissionException("first name should be alphabet and Minimum 3 and maximum");
		}
	}
	public  static  boolean validatelastName(String lastName)throws AdmissionException
	{
		String assetPattern="[A-Za-z]{3,15}";
		if(Pattern.matches(assetPattern, lastName))
		{
			return true;
		}
		else
		{
			throw new AdmissionException("last name should be alphabet and Minimum 3 and maximum 15");
		}
	}
	
	public  static  boolean validatemobileNo(String mobileNo)throws AdmissionException
	{
		String assetPattern="[7-9][0-9]{9}";
		if(Pattern.matches(assetPattern, mobileNo))
		{
			return true;
		}
		else
		{
			throw new AdmissionException("Mobile No. should be only 10-digit number starting with 7 / 8 / 9");
		}
	}
	
	public  static  boolean validateemail(String email)throws AdmissionException
	{
		String assetPattern="^[a-zA-Z0-9_!#$%&'*+/=?`{|}~^.-]+@[a-zA-Z0-9.-]+$";
		if(Pattern.matches(assetPattern, email))
		{
			return true;
		}
		else
		{
			throw new AdmissionException("Email id should contain @ and symbol. E.g. someone@gmail.com");
		}
	}
	
	public  static  boolean validatestream(String stream)throws AdmissionException
	{

		if((stream.equalsIgnoreCase("Computer Science")||(stream.equalsIgnoreCase("Information Technology"))))
		{
			return true;
		}
		else
		{
			throw new AdmissionException("Stream should be either Computer Science or Information Technology");
		}
	}
	
	public  static  boolean validateaggMarks(double aggMarks)throws AdmissionException
	{
		String amarks=String.valueOf(aggMarks);
		String assetPattern="[0-9]{1,3}[.][0-9]";
		if(Pattern.matches(assetPattern, amarks))
		{
			return true;
		}
		else
		{
			throw new AdmissionException("Aggregate marks must accept only digits.");
		}
	}
}
