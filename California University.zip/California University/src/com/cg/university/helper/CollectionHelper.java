package com.cg.university.helper;

import java.util.ArrayList;
import java.util.Iterator;

import com.cg.university.bean.AdmissionDetails;
import com.cg.university.helper.CollectionHelper;

public class CollectionHelper 
{
	public static ArrayList<AdmissionDetails> AdmissionList=null;
	
	static
	{
		AdmissionList=new ArrayList<>();
	}

	
	public CollectionHelper(){}
	
	//adding Admission details to the array list
	public void addNewAdmission(AdmissionDetails admissionDetails) 
	{			
			
			AdmissionList.add(admissionDetails);
			
			System.out.println("Admission details added successfully");
	}
	
	public static ArrayList<AdmissionDetails> getAdmissionList() {
		return AdmissionList;
	}

	public static void setAdmissionList(ArrayList<AdmissionDetails> AdmissionList) {
		CollectionHelper.AdmissionList = AdmissionList;
	}

	//displaying all Admission details
	public void displayAllAdmissions()
	{
		Iterator<AdmissionDetails> AdmissionIt=AdmissionList.iterator();
		AdmissionDetails tempAdmission=new AdmissionDetails();
		while(AdmissionIt.hasNext())
		{
			tempAdmission=AdmissionIt.next();
			System.out.println(tempAdmission);			
		}
	}
	public boolean deleteAdmissions(String mobile)
	{	boolean deleted=false;
		try{

		Iterator<AdmissionDetails> AdmissionIt=AdmissionList.iterator();
		AdmissionDetails tempAdmission=new AdmissionDetails();
		
		while(AdmissionIt.hasNext())
		{
			tempAdmission=AdmissionIt.next();
			if(mobile.equals(tempAdmission.setmobileNo())){
			AdmissionList.remove(tempAdmission);
			deleted=true;
			}
			else
				deleted=false;		
		}
		return deleted;
	}
		catch(Exception e){
			//e.printStackTrace();
			
			System.out.println("Size: "+AdmissionList.size()+"Error:"+e.getMessage());
			deleted=false;
			return deleted;
		}
		
	}
	public void numberAdmissions()
	{
	
	}
}
